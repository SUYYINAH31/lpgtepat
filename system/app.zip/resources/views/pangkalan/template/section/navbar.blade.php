<div class="container">
    <a class="navbar-brand" href="index.html">
        <i class="bi-back"></i>
        <span>SUBSIDI TEPAT</span>
    </a>

    <div class="d-lg-none ms-auto me-4">
        <a href="#top" class="navbar-icon bi-person smoothscroll"></a>
    </div>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-lg-5 me-lg-auto">
            <li class="nav-item">
                <a class="nav-link" href="">Cek Nik</a>
            </li>

            <li class="nav-item">
                <a class="nav-link " href="">Laporan penjualan</a>
            </li>

            <li class="nav-item">
                <a class="nav-link " href="">Atur Produk</a>
            </li>

            <li class="nav-item">
                <a class="nav-link " href="">Profil Saya</a>
            </li>

           
        </ul>

      
    </div>
</div>